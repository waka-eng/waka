# WAKA MCP

A profile-bound memory interface for the one WAKA companion. New personal
connections use **Settings → My profile · MCP**. New browser consent binds human
memory; existing legacy-agent credentials remain isolated and retained. Do not
create an agent profile to connect.

Install the immutable package URL from that setup page with Node.js 20+ and npm.
No source checkout, local build, database or provider key is required. Each entry
must pin `WAKA_PROFILE_ID`; key connections use `WAKA_API_URL` and `WAKA_API_KEY`.
Never paste keys into chat or commit configuration containing a key. A browser
login is broader than a keeper key; personal setup defaults to a keeper key.

## Access

Choose a server-issued `read_only` keeper key for operational readers. Set
`WAKA_MCP_MODE=read_only` as defense in depth: capture is not registered and is
also denied by the client. This mode refuses a broader key rather than pretending
it became read-only. The backend independently blocks capture/harvest/curation,
including direct HTTP bypass. Existing `read_capture` keys retain their scope;
changing mode does not rotate or revoke them.

Read-only means no memory mutation. Auth verification/last-used metadata and
consultation receipts are still written. Semantic recall may make one bounded
embedding call, limited account-wide to 10 attempts/minute and 60/hour. This is
an attempt limit, not a dollar spending cap. Empty eligible-vector sets spend
nothing. Provider failure is explicit; no invented semantic scores or fallback.

## Tools

- `waka_verify_connection`: verify the exact bound profile; writes verification metadata.
- `waka_add_inspiration`: existing text capture, available only in capture mode.
- `waka_get_capture_status`: reconcile the same save ID and inspect current processing.
- `waka_list_inspirations`: paginated previews, not verbatim full captures.
- `waka_get_inspiration`: on-demand owned text/reflections (shared maximum 32,768 characters), explicit truncation, safe media IDs/types only.
- `waka_list_signals`: patterns with support, owner-lock and conflict qualifiers.
- `waka_get_signal`: current evidence, up to 20 inspiration and 20 review witnesses.
- `waka_recall`: current supported signals in the matching vector space; paid query embedding and a read receipt. Use list/detail if unavailable.
- `waka_get_profile`: the bound profile's current top-of-mind artifact.
- `waka_get_principles`: exact canonical markdown in one memory read, including empty state; never generation on GET.
- `waka_list_profiles`: only the bound profile.

Owner-locked wording must not be regenerated; a lock does not prove the owner
authored every word. Withdrawn/pending support is not current proof. No tool
provides chat, edit/delete, curation, account administration, agent creation,
media uploads, decision capture or harvest submission.

## Capture reliability

For each NEW save, generate a UUID `requestId` once and retain it with the exact
material. The tool sends `Idempotency-Key`; capture, processing receipt and save
identity commit together. Success means **committed capture**, not completed
background derivation (which can spend model calls).

After timeout, transport/body failure, malformed success, or an uncertain server
response: call `waka_get_capture_status` with that SAME ID. `not_observed` means
no committed row observed yet; an in-flight transaction can still commit. Do not
choose another ID or automatically retry. A deliberate retry must reuse the ID
and exact original material; changed material conflicts. Status never retries
processing. Requests have a 15-second deadline including body consumption, a
4-MiB response ceiling, and safe closed errors without raw server bodies.

## Upgrade

Version 0.2 requires the refreshed API for capture, read-only capability and
current detail contracts. Update/reinstall using the new immutable URL; an
already installed old client does not update when the website changes. Old
archives remain available and their keyless saves retain their original
non-idempotent behavior. No account/key migration or vector backfill is needed.

Maintainers: `pnpm install --frozen-lockfile --ignore-scripts`, `pnpm typecheck`,
`pnpm test`, `pnpm build`, `pnpm audit --prod --audit-level=low`. Default tests are
offline; no paid/live suite is part of CI. App packaging pins a published client
source commit and retains old archives. PRs target `dev`; no main release is
implied by a client change.
