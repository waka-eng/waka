# WAKA MCP client

Install from the package URL shown in WAKA Settings → Agent profiles → your agent. Node.js 20+ and npm are required. Git, pnpm, repository access and a local build are not required.

Use `waka-login` for browser sign-in and `waka-mcp` as the MCP server executable. Each connection must pin WAKA_PROFILE_ID. Browser sign-ins also use a separate WAKA_HOME per profile. API key connections use WAKA_API_URL and WAKA_API_KEY.

This archive contains the bundled client and dependency notices, not the WAKA backend or a source checkout.
